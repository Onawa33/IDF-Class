def miles(kilometers):
    return kilometers * .6214

def main():
    kilometers = int(input("Input kilometers to convert to miles: "))
    print(miles(kilometers))

main()
