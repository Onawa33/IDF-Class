def main():
    arg = int(input("Input a number to multiply: "))
    multiply()
def multiply()
    answer = arg * 10
    print(" ", answer)
main()
