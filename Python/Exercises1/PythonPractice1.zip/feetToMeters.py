feet = float(input("Input feet: "))
print("Feet in meters: %.2f" %(feet * .305))
