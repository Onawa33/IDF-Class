item1 = float(input("Input first item price: "))
item2 = float(input("Input second item price: "))
item3 = float(input("Input third item price: "))
item4 = float(input("Input fourth item price: "))
item5 = float(input("Input fifth item price: "))
total = item1 + item2 + item3 + item4 + item5
tax = total * .06
print("Your subtotal is: $%.2f " %(total))
print("Tax is: $%.2f " %(tax))
print("The total plus tax is: $%.2f " %(total + tax))


    
