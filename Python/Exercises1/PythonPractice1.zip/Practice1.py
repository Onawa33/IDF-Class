fname = input("Input your first name: ")
lname = input("Input your last name: ")
print("Hello " + lname + " " + fname)
