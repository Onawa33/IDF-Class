total = float(input("Input projected total sales: "))
print("Projected profit is: ", total * .23)
