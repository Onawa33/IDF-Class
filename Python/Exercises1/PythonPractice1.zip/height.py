height = float(input("Input your height in inches: "))
print("Your height is: ", height)
