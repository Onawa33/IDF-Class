miles = float(input("Input the miles driven: "))
gallons = float(input("Input the gallons used: "))
MPG = miles / gallons
print("Miles per gallon: ", MPG)
