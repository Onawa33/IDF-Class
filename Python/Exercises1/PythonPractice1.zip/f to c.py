celsius = float(input("Input the temp in celsius: "))
fahrenheit = (9/5) * celsius + 32
print("Converted to fahrenheit: %.2f" %(fahrenheit))
